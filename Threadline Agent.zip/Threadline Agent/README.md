# Revenue-Growth Agent — Agent-Readable Catalog + Upsell/Cross-Sell

**Track 01: AI Growth & Agentic Commerce**
Grows a merchant's revenue by proposing bounded, explainable upsell/cross-sell
offers from an agent-readable catalog, then checks out through Razorpay
test-mode APIs.

## Why this design

- **Agent-readable catalog** (`catalog_tools.py`): the catalog isn't a blob
  of prose an LLM has to parse — it's a small set of typed, documented
  functions (`search_catalog`, `get_product`, `get_related`, `check_stock`)
  that any AI agent (via function-calling / MCP-style tool use) can call
  directly. Cross-sell/upsell relationships are explicit graph edges on
  each product, not inferred similarity — so every recommendation is
  traceable to a stated fact in the catalog, not a black-box guess.

- **Revenue agent** (`agent.py`): walks the customer's cart, looks up
  `upsell`/`cross_sell` edges for each line, and proposes add-ons —
  every one with a plain-English `reason`.

## How it meets "The Bar"

| Requirement | Where |
|---|---|
| **Explainable** | Every offer carries a `reason` string tied to a specific catalog relationship. Every audit entry has an `explanation` field. |
| **Bounded** | `MAX_ADDON_PCT_OF_SUBTOTAL` (30%), `MAX_ADDON_ITEMS` (2), stock checks, and `MAX_ORDER_VALUE` (₹10,000) are centralized policy constants in `agent.py`, checked before any offer or charge. |
| **Gated** | `checkout()` refuses to call Razorpay unless `user_confirmed=True` is passed in explicitly — no silent charges. |
| **Audit trail** | `audit.py` writes a JSONL log (`audit_log.jsonl`) of every proposal, rejection, gate check, and checkout outcome. `AuditTrail.print_trail()` renders it. |
| **Graceful failure** | `razorpay_client.py`'s mock client injects one simulated gateway timeout; `call_with_retry()` retries with backoff, and a failure that survives retries returns a clean `status: failed` with nothing charged — never a crash. |

## Run it

```bash
cd agent
python3 main.py
```

No API keys needed — it runs against `MockRazorpayClient`, which mimics
Razorpay's Orders API response shape (including one injected transient
failure so you can see the retry path).

## Going live with real Razorpay test-mode keys

```bash
pip install razorpay
export RAZORPAY_KEY_ID=rzp_test_xxxxxxxxxxxx
export RAZORPAY_KEY_SECRET=xxxxxxxxxxxxxxxx
python3 main.py
```

`razorpay_client.get_client()` automatically switches to `RealRazorpayClient`
when both env vars are present — no other code changes needed.

## Files

```
agent/
├── data/catalog.json     # sample merchant catalog (5 SKUs, cross-sell/upsell graph)
├── catalog_tools.py       # agent-readable catalog interface (the "tools")
├── agent.py                # RevenueAgent: propose_offers() + checkout()
├── razorpay_client.py       # Real + Mock Razorpay clients, retry helper
├── audit.py                  # JSONL audit trail
├── main.py                    # end-to-end demo
└── README.md
```

## Extending toward the other example directions

- **Conversational in-app checkout**: wrap `RevenueAgent` in an LLM loop
  that calls the `catalog_tools` functions as tools and calls
  `agent.checkout(..., user_confirmed=True)` only after the user types
  a clear "yes"/"confirm" in the chat.
- **Campaign orchestrator**: run `propose_offers()` across many carts on a
  schedule, aggregate accepted offers, and push them as a merchant-facing
  campaign report using the same audit trail for transparency.
- Swap `data/catalog.json` for a live Razorpay merchant catalog / product
  feed — `catalog_tools.py`'s function signatures stay the same.
