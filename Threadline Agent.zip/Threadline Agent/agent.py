"""
agent.py

The revenue-growth agent. Given a cart, it:
  1. Proposes cross-sell / upsell add-ons sourced from the agent-readable
     catalog graph (catalog_tools.py) -- every suggestion carries an
     explicit reason.
  2. Applies bounds so it can never propose something reckless:
       - max add-on value as a % of cart subtotal
       - max number of add-on line items
       - stock must actually be available
  3. Gates any money-moving action behind explicit user confirmation.
  4. Executes checkout via Razorpay test-mode (or mock), with retry and
     graceful failure handling.
  5. Logs every step to the audit trail.

Policy constants are intentionally simple and centralized so they're easy
to review -- this is the "bounded" half of the bar.
"""

from dataclasses import dataclass, field
from typing import List, Dict

import catalog_tools as ct
from razorpay_client import get_client, call_with_retry, RazorpayError
from audit import AuditTrail

# ---- Policy (the "bounded" part) ------------------------------------------
MAX_ADDON_PCT_OF_SUBTOTAL = 0.30   # add-ons can't exceed 30% of cart subtotal
MAX_ADDON_ITEMS = 2                # never propose more than 2 add-on lines
MAX_ORDER_VALUE = 10000.00         # hard ceiling on any single order (INR)


@dataclass
class CartLine:
    sku: str
    quantity: int


@dataclass
class Offer:
    sku: str
    name: str
    price: float
    quantity: int
    relation: str          # "cross_sell" or "upsell"
    source_sku: str        # which cart item triggered this
    reason: str


@dataclass
class Cart:
    lines: List[CartLine] = field(default_factory=list)

    def subtotal(self) -> float:
        total = 0.0
        for line in self.lines:
            p = ct.get_product(line.sku)
            if p:
                total += p["price"] * line.quantity
        return total


class RevenueAgent:
    def __init__(self, audit: AuditTrail = None):
        self.audit = audit or AuditTrail()
        self.rzp = get_client()

    # ---- Step 1+2: propose bounded, explainable offers --------------------
    def propose_offers(self, cart: Cart) -> List[Offer]:
        subtotal = cart.subtotal()
        addon_budget = subtotal * MAX_ADDON_PCT_OF_SUBTOTAL
        candidates: List[Offer] = []

        for line in cart.lines:
            product = ct.get_product(line.sku)
            if not product:
                continue

            for related in ct.get_related(line.sku, "upsell"):
                candidates.append(Offer(
                    sku=related["sku"], name=related["name"], price=related["price"],
                    quantity=line.quantity, relation="upsell", source_sku=line.sku,
                    reason=f"Upgrade from '{product['name']}' to '{related['name']}' "
                           f"(same category, higher-spec material)."
                ))

            for related in ct.get_related(line.sku, "cross_sell"):
                candidates.append(Offer(
                    sku=related["sku"], name=related["name"], price=related["price"],
                    quantity=1, relation="cross_sell", source_sku=line.sku,
                    reason=f"Frequently paired with '{product['name']}' in this catalog."
                ))

        accepted: List[Offer] = []
        running_addon_cost = 0.0
        for offer in candidates:
            if len(accepted) >= MAX_ADDON_ITEMS:
                self.audit.record(
                    action="offer_rejected", explanation=offer.reason,
                    bounds={"rule": "MAX_ADDON_ITEMS", "limit": MAX_ADDON_ITEMS, "passed": False},
                    gate={"required": False}, status="rejected",
                    extra={"sku": offer.sku, "cause": "max_addon_items_reached"},
                )
                continue

            if not ct.check_stock(offer.sku, offer.quantity):
                self.audit.record(
                    action="offer_rejected", explanation=offer.reason,
                    bounds={"rule": "stock_available", "passed": False},
                    gate={"required": False}, status="rejected",
                    extra={"sku": offer.sku, "cause": "out_of_stock"},
                )
                continue

            line_cost = offer.price * offer.quantity
            if running_addon_cost + line_cost > addon_budget:
                self.audit.record(
                    action="offer_rejected", explanation=offer.reason,
                    bounds={
                        "rule": "MAX_ADDON_PCT_OF_SUBTOTAL",
                        "limit_pct": MAX_ADDON_PCT_OF_SUBTOTAL,
                        "addon_budget": round(addon_budget, 2),
                        "would_total": round(running_addon_cost + line_cost, 2),
                        "passed": False,
                    },
                    gate={"required": False}, status="rejected",
                    extra={"sku": offer.sku, "cause": "exceeds_addon_budget"},
                )
                continue

            running_addon_cost += line_cost
            accepted.append(offer)
            self.audit.record(
                action="offer_proposed", explanation=offer.reason,
                bounds={
                    "rule": "MAX_ADDON_PCT_OF_SUBTOTAL",
                    "limit_pct": MAX_ADDON_PCT_OF_SUBTOTAL,
                    "addon_budget": round(addon_budget, 2),
                    "running_total": round(running_addon_cost, 2),
                    "passed": True,
                },
                gate={"required": False},
                amount=line_cost, currency="INR",
                extra={"sku": offer.sku, "relation": offer.relation},
            )

        return accepted

    # ---- Step 3+4: gated checkout -----------------------------------------
    def checkout(self, cart: Cart, accepted_offers: List[Offer], user_confirmed: bool) -> Dict:
        final_lines = list(cart.lines) + [
            CartLine(sku=o.sku, quantity=o.quantity) for o in accepted_offers
        ]
        total = sum(
            (ct.get_product(l.sku)["price"] * l.quantity)
            for l in final_lines if ct.get_product(l.sku)
        )

        bounds_check = {
            "rule": "MAX_ORDER_VALUE", "limit": MAX_ORDER_VALUE,
            "order_total": round(total, 2), "passed": total <= MAX_ORDER_VALUE,
        }

        if not bounds_check["passed"]:
            self.audit.record(
                action="checkout_blocked",
                explanation="Order total exceeds the merchant's configured per-order ceiling.",
                bounds=bounds_check, gate={"required": True, "confirmed": user_confirmed},
                amount=total, currency="INR", status="blocked",
            )
            return {"status": "blocked", "reason": "order_exceeds_max_value", "total": total}

        gate = {"required": True, "confirmed": user_confirmed}
        if not user_confirmed:
            self.audit.record(
                action="checkout_gated",
                explanation="Checkout requires explicit user confirmation before any charge is created.",
                bounds=bounds_check, gate=gate, amount=total, currency="INR",
                status="awaiting_confirmation",
            )
            return {"status": "awaiting_confirmation", "total": total}

        # gate passed -> attempt payment via Razorpay test-mode (with retry)
        amount_paise = int(round(total * 100))
        notes = {
            "merchant_id": ct.get_catalog_info()["merchant_id"],
            "line_items": ",".join(f"{l.sku}x{l.quantity}" for l in final_lines),
        }

        result, attempts, error = call_with_retry(
            self.rzp.create_order,
            amount_paise=amount_paise, currency="INR",
            receipt=f"receipt_{ct.get_catalog_info()['merchant_id']}",
            notes=notes,
        )

        if error:
            self.audit.record(
                action="checkout_failed",
                explanation="Razorpay order creation failed after retries; "
                            "no charge was made, cart left intact for the user.",
                bounds=bounds_check, gate=gate, amount=total, currency="INR",
                status="failed",
                extra={"attempts": attempts, "error": str(error)},
            )
            return {"status": "failed", "error": str(error), "attempts": attempts}

        self.audit.record(
            action="checkout_succeeded",
            explanation="User confirmed; order created via Razorpay test-mode API.",
            bounds=bounds_check, gate=gate, amount=total, currency="INR",
            status="succeeded",
            extra={"attempts": attempts, "razorpay_order_id": result["id"], "line_items": notes["line_items"]},
        )
        return {"status": "succeeded", "order": result, "total": total, "attempts": attempts}
