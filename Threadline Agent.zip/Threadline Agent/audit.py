"""
audit.py

Append-only audit trail for every money-adjacent action the agent takes.
Every entry answers three questions ("The Bar"):
  - explainable: why did the agent do this? (`explanation`)
  - bounded: what limit was checked, and did it pass? (`bounds`)
  - gated: was explicit confirmation required, and was it obtained? (`gate`)
"""

import json
import os
import time
from datetime import datetime, timezone

_LOG_PATH = os.path.join(os.path.dirname(__file__), "audit_log.jsonl")


class AuditTrail:
    def __init__(self, path: str = _LOG_PATH):
        self.path = path
        # start fresh each run for a clean demo trail
        open(self.path, "w").close()

    def record(self, action: str, explanation: str, bounds: dict, gate: dict,
               amount: float = None, currency: str = None, status: str = "ok",
               extra: dict = None):
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "action": action,
            "explanation": explanation,
            "bounds": bounds,
            "gate": gate,
            "amount": amount,
            "currency": currency,
            "status": status,
            "extra": extra or {},
        }
        with open(self.path, "a") as f:
            f.write(json.dumps(entry) + "\n")
        return entry

    def read_all(self) -> list:
        if not os.path.exists(self.path):
            return []
        entries = []
        with open(self.path, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    entries.append(json.loads(line))
        return entries

    def print_trail(self):
        entries = self.read_all()
        print("\n" + "=" * 70)
        print("AUDIT TRAIL")
        print("=" * 70)
        for e in entries:
            print(f"\n[{e['timestamp']}] {e['action'].upper()}  status={e['status']}")
            print(f"  explanation: {e['explanation']}")
            print(f"  bounds:      {e['bounds']}")
            print(f"  gate:        {e['gate']}")
            if e["amount"] is not None:
                print(f"  amount:      {e['amount']} {e['currency']}")
            if e["extra"]:
                print(f"  extra:       {e['extra']}")
        print("\n" + "=" * 70)
