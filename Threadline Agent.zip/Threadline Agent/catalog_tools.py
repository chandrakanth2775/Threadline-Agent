"""
catalog_tools.py

Exposes the merchant catalog as a small set of well-typed, documented
functions ("tools") that an AI agent can call. This is the "agent-readable
catalog" surface: any LLM-driven agent (via function-calling / MCP-style
tool use) can introspect these signatures and call them directly.

Design choices for agent-readability:
- Stable SKUs as primary keys (never free-text product names).
- Explicit, typed attributes (no prose parsing required).
- Explicit cross_sell / upsell graph edges instead of implicit similarity,
  so an agent's recommendation is always traceable to a stated relationship.
"""

import json
import os
from typing import Optional

_CATALOG_PATH = os.path.join(os.path.dirname(__file__), "data", "catalog.json")


def _load_catalog() -> dict:
    with open(_CATALOG_PATH, "r") as f:
        return json.load(f)


_CATALOG = _load_catalog()
_PRODUCTS_BY_SKU = {p["sku"]: p for p in _CATALOG["products"]}


# ---- Agent-callable tools -------------------------------------------------

def get_catalog_info() -> dict:
    """Tool: get_catalog_info()
    Returns merchant identity and currency so an agent knows what store
    it's operating on before making any calls.
    """
    return {
        "merchant_id": _CATALOG["merchant_id"],
        "merchant_name": _CATALOG["merchant_name"],
        "currency": _CATALOG["currency"],
        "schema_version": _CATALOG["schema_version"],
    }


def search_catalog(category: Optional[str] = None, query: Optional[str] = None) -> list:
    """Tool: search_catalog(category?, query?)
    Returns products filtered by category prefix and/or a case-insensitive
    substring match on name/description. Returns full structured product
    records, never prose, so results are directly actionable.
    """
    results = []
    for p in _CATALOG["products"]:
        if category and not p["category"].startswith(category):
            continue
        if query:
            q = query.lower()
            if q not in p["name"].lower() and q not in p["description"].lower():
                continue
        results.append(p)
    return results


def get_product(sku: str) -> Optional[dict]:
    """Tool: get_product(sku)
    Returns the full structured record for a single SKU, or None if unknown.
    """
    return _PRODUCTS_BY_SKU.get(sku)


def get_related(sku: str, relation: str) -> list:
    """Tool: get_related(sku, relation)
    relation must be 'cross_sell' or 'upsell'. Returns the related product
    records (not just SKUs) so the agent has price/stock/attributes to
    reason with immediately.
    """
    if relation not in ("cross_sell", "upsell"):
        raise ValueError("relation must be 'cross_sell' or 'upsell'")
    product = _PRODUCTS_BY_SKU.get(sku)
    if not product:
        return []
    related_skus = product.get(relation, [])
    return [_PRODUCTS_BY_SKU[s] for s in related_skus if s in _PRODUCTS_BY_SKU]


def check_stock(sku: str, quantity: int) -> bool:
    """Tool: check_stock(sku, quantity)
    Returns True if quantity units of sku are available.
    """
    product = _PRODUCTS_BY_SKU.get(sku)
    if not product:
        return False
    return product["stock"] >= quantity


TOOL_REGISTRY = {
    "get_catalog_info": get_catalog_info,
    "search_catalog": search_catalog,
    "get_product": get_product,
    "get_related": get_related,
    "check_stock": check_stock,
}
