"""
main.py -- end-to-end demo of the agent-readable catalog + revenue agent.

Run:
    python3 main.py

Simulates:
  1. A customer cart (built via the agent-readable catalog tools).
  2. The agent proposing bounded, explainable upsell/cross-sell offers.
  3. The user confirming.
  4. Checkout hitting one simulated Razorpay failure, retrying, and
     succeeding -- demonstrating graceful failure handling.
  5. Printing the full audit trail.
"""

import catalog_tools as ct
from agent import RevenueAgent, Cart, CartLine
from audit import AuditTrail


def main():
    print("=" * 70)
    print(f"Merchant: {ct.get_catalog_info()['merchant_name']}  "
          f"({ct.get_catalog_info()['merchant_id']})")
    print("=" * 70)

    # 1) Customer's starting cart
    cart = Cart(lines=[CartLine(sku="TS-BLK-M", quantity=2)])
    print(f"\nCustomer cart: 2x {ct.get_product('TS-BLK-M')['name']} "
          f"(₹{ct.get_product('TS-BLK-M')['price']:.2f} each)")
    print(f"Subtotal: ₹{cart.subtotal():.2f}")

    audit = AuditTrail()
    agent = RevenueAgent(audit=audit)

    # 2) Agent proposes bounded, explainable offers
    print("\n--- Agent evaluating upsell / cross-sell offers ---")
    offers = agent.propose_offers(cart)
    if not offers:
        print("No offers passed the agent's bounds.")
    for o in offers:
        print(f"  + Suggested: {o.name} (₹{o.price:.2f}) [{o.relation}]")
        print(f"    why: {o.reason}")

    # 3) Present to user, get confirmation (simulated: user accepts)
    addon_total = sum(o.price * o.quantity for o in offers)
    print(f"\nAgent to user: \"I'd suggest adding these for ₹{addon_total:.2f} more -- "
          f"want me to add them and check out?\"")
    user_confirmed = True
    print(f"User: \"Yes, go ahead.\" (confirmed={user_confirmed})")

    # 4) Gated checkout -- will hit one simulated failure, then retry
    print("\n--- Agent attempting checkout (gated on confirmation) ---")
    result = agent.checkout(cart, offers, user_confirmed=user_confirmed)

    if result["status"] == "succeeded":
        print(f"Checkout succeeded after {result['attempts']} attempt(s).")
        print(f"Razorpay order id: {result['order']['id']}")
        print(f"Total charged: ₹{result['total']:.2f}")
    elif result["status"] == "failed":
        print(f"Checkout failed after {result['attempts']} attempt(s): {result['error']}")
        print("Agent to user: \"I couldn't complete checkout right now -- "
              "nothing was charged. Want me to try again?\"")
    else:
        print(f"Checkout status: {result['status']} -- {result}")

    # 5) Show the full audit trail
    audit.print_trail()


if __name__ == "__main__":
    main()
