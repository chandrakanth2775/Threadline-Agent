"""
razorpay_client.py

Thin wrapper over Razorpay's test-mode APIs (Orders + Payment Links).
If RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET are not set in the environment,
falls back to a MockRazorpayClient so the whole pipeline is runnable and
demoable without live credentials.

To go live with real Razorpay test-mode keys:
    pip install razorpay
    export RAZORPAY_KEY_ID=rzp_test_xxxxx
    export RAZORPAY_KEY_SECRET=xxxxx
"""

import os
import time
import uuid
import random


class RazorpayError(Exception):
    pass


class RealRazorpayClient:
    """Wraps the official `razorpay` Python SDK, test-mode keys only."""

    def __init__(self, key_id: str, key_secret: str):
        import razorpay  # imported lazily so mock mode has no hard dependency
        self.client = razorpay.Client(auth=(key_id, key_secret))

    def create_order(self, amount_paise: int, currency: str, receipt: str, notes: dict) -> dict:
        try:
            return self.client.order.create({
                "amount": amount_paise,
                "currency": currency,
                "receipt": receipt,
                "notes": notes,
            })
        except Exception as e:
            raise RazorpayError(str(e))

    def create_payment_link(self, amount_paise: int, currency: str, description: str, notes: dict) -> dict:
        try:
            return self.client.payment_link.create({
                "amount": amount_paise,
                "currency": currency,
                "description": description,
                "notes": notes,
            })
        except Exception as e:
            raise RazorpayError(str(e))


class MockRazorpayClient:
    """
    Simulates Razorpay's test-mode API surface locally, including one
    injected transient failure so the agent's failure-handling path can be
    demonstrated end to end without needing to break a real network call.
    """

    def __init__(self, fail_once: bool = True):
        self._fail_once = fail_once
        self._has_failed = False

    def _maybe_inject_failure(self):
        if self._fail_once and not self._has_failed:
            self._has_failed = True
            raise RazorpayError("Simulated gateway timeout (mock, for demo purposes)")

    def create_order(self, amount_paise: int, currency: str, receipt: str, notes: dict) -> dict:
        self._maybe_inject_failure()
        return {
            "id": f"order_MOCK{uuid.uuid4().hex[:14]}",
            "entity": "order",
            "amount": amount_paise,
            "currency": currency,
            "receipt": receipt,
            "status": "created",
            "notes": notes,
            "created_at": int(time.time()),
        }

    def create_payment_link(self, amount_paise: int, currency: str, description: str, notes: dict) -> dict:
        self._maybe_inject_failure()
        link_id = f"plink_MOCK{uuid.uuid4().hex[:14]}"
        return {
            "id": link_id,
            "entity": "payment_link",
            "amount": amount_paise,
            "currency": currency,
            "description": description,
            "status": "created",
            "short_url": f"https://rzp.io/l/{link_id[-8:]}",
            "notes": notes,
            "created_at": int(time.time()),
        }


def get_client():
    key_id = os.environ.get("RAZORPAY_KEY_ID")
    key_secret = os.environ.get("RAZORPAY_KEY_SECRET")
    if key_id and key_secret:
        return RealRazorpayClient(key_id, key_secret)
    return MockRazorpayClient(fail_once=True)


def call_with_retry(fn, *args, max_attempts: int = 2, backoff_seconds: float = 0.4, **kwargs):
    """
    Calls fn with simple retry + backoff. Returns (result, attempts, error)
    where error is None on success, or the last RazorpayError if every
    attempt failed -- callers decide how to fail gracefully.
    """
    last_error = None
    for attempt in range(1, max_attempts + 1):
        try:
            result = fn(*args, **kwargs)
            return result, attempt, None
        except RazorpayError as e:
            last_error = e
            if attempt < max_attempts:
                time.sleep(backoff_seconds)
    return None, max_attempts, last_error
